<?php return [
	'Cookiewarning Settings'                                                                                                  => 'Настройки расширения',
	'Position'                                                                                                                => 'Позиция',
	'Bottom'                                                                                                                  => 'Внизу',
	'Top'                                                                                                                     => 'Наверху',
	'Bottom-Left'                                                                                                             => 'Слева внизу',
	'Bottom-Right'                                                                                                            => 'Справа внизу',
	'Theme'                                                                                                                   => 'Тема',
	'Classic'                                                                                                                 => 'Классическая',
	'Block'                                                                                                                   => 'Блок',
	'Edgeless'                                                                                                                => 'Без границ',
	'Popup-Background-Colour'                                                                                                 => 'Фоновый цвет сообщения',
	'Popup-Text-Colour'                                                                                                       => 'Цвет текста сообщения',
	'Button-Background-Colour'                                                                                                => 'Фоновый цвет кнопки',
	'Button-Text-Colour'                                                                                                      => 'Цвет текста кнопки',
	'Message'                                                                                                                 => 'Сообщение',
	'Overwrite message'                                                                                                       => 'Изменить текст сообщения',
	'Overwrite dismiss-button'                                                                                                => 'Изменить текст кнопки',
	'Dismiss-Button-Text'                                                                                                     => 'Текст кнопки',
	'Policy URL'                                                                                                              => 'Политика конфиденциальности: URL',
	'Policy-Link-Text'                                                                                                        => 'Политика конфиденциальности: текст ссылки',
	'Overwrite Policy-Link-Text'                                                                                              => 'Изменить текст ссылки',
	'Dismiss'                                                                                                                 => 'Закрыть',
	'Learn more'                                                                                                              => 'Узнать больше',
	'This website uses cookies. This ensures that the website is working correctly for your best experience on this website.' => 'Веб-сайт использует cookie-файлы для корректной работы. Пожалуйста, ознакомьтесь с политикой конфиденциальности.'


];
